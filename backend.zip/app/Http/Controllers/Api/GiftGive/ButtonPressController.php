<?php

namespace App\Http\Controllers\Api\GiftGive;

use App\Http\Controllers\Controller;
use App\Http\Requests\RequestApi\ButtonPress\StoreButtonPressRequest;
use App\Services\DabdobyMoodService;
use Illuminate\Http\JsonResponse;

class ButtonPressController extends Controller
{
    /**
     * تسجيل ضغطة فقط. الحالة الحالية للدبدوب بتيجي من الـ me.
     * (بنرجّع الـ mood برضه للراحة، بس الفرونت يعتمد على الـ me.)
     */
    public function store(StoreButtonPressRequest $request, DabdobyMoodService $mood): JsonResponse
    {
        $user = auth('api')->user();

        $press = $user->buttonPresses()->create([
            'button' => $request->button,
        ]);

        return response()->json([
            'status'  => true,
            'message' => 'Press saved',
            'data'    => [
                'press' => $press->only(['id', 'button', 'delivered', 'created_at']),
                'mood'  => $mood->for($user),
            ],
        ], 201);
    }
}
